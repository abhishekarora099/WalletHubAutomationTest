package com.Wallethub.Assignments.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.Wallethub.Assignments.automation.factory.DataProviderFactory;
import com.Wallethub.Assignments.automation.utils.Utility;

public class WallethubPage {

	public WebDriver driver;

	@FindBy(xpath = "//input[@id='em-ipt']")
	WebElement EmailAddress;

	@FindBy(xpath = "//input[@id='pw1-ipt']")
	WebElement Password;

	@FindBy(xpath = "//input[@id='pw2-ipt']")
	WebElement ConfirmPassword;

	@FindBy(xpath = "//span[@id='get-my-report']")
	WebElement FreeCreditScoreCheckbox;

	@FindBy(xpath = "//button[@type='button']")
	WebElement JoinButton;

	@FindBy(xpath = "//span[@class='nav-txt'][normalize-space()='Reviews']")
	WebElement ReviewsSection;

	@FindBy(xpath = "//div[@class='dropdown second']")
	WebElement PolicyDropDown;

	@FindBy(xpath = "//li[normalize-space()='Health Insurance']")
	WebElement HealthInsurance;

	@FindBy(xpath = "//textarea[contains(@placeholder,'your review')]")
	WebElement WriteAReviewLink;

	@FindBy(xpath = "//div[contains(text(),'Submit')]")
	WebElement SubmitButton;

	@FindBy(xpath = "//div[contains(text(),'WalletHub is the best destination for free credit scores & reports updated daily')]")
	WebElement ValidateReview;

	public WallethubPage(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void navigateToWallethubRegistrationPage() {

		driver.get(DataProviderFactory.getConfigDataProvider().getValue("url2"));

	}

	public void enterEmailAddress() {

		Utility.sendKeysAction(driver, EmailAddress, DataProviderFactory.getConfigDataProvider().getValue("email2"));

	}

	public void enterPassword() {

		Utility.sendKeysAction(driver, Password, DataProviderFactory.getConfigDataProvider().getValue("password2"));

	}

	public void enterConfirmPassword() {

		Utility.sendKeysAction(driver, ConfirmPassword,
				DataProviderFactory.getConfigDataProvider().getValue("password2"));

	}

	public void clickOnFreeCreditScoreCheckbox() {
		Utility.moveToElementAndClickAction(driver, FreeCreditScoreCheckbox);

	}

	public void clickOnJoinButton() {
		Utility.moveToElementAndClickAction(driver, JoinButton);
		Utility.sleep(5);

	}

	public void navigateToTestInsuranceCompanyUrl() {

		driver.get(DataProviderFactory.getConfigDataProvider().getValue("url3"));
	}

	public void clickOnReviewsSection() {

		Utility.moveToElementAndClickAction(driver, ReviewsSection);

	}

	public void hoverOnRatingStars() {

		List<WebElement> RatingStars = driver.findElements(
				By.xpath("//review-star[@class='rvs-svg']//div[@class='rating-box-wrapper']//*[local-name()='svg']"));

		int i;
		for (i = 1; i < RatingStars.size() - 1; i++)

		{
			Utility.moveToElement(driver, RatingStars.get(i));

		}

		RatingStars.get(i).click();
	}

	public void clickOnWriteAReviewLink() {

		Utility.moveToElementAndClickAction(driver, WriteAReviewLink);
	}

	public void enterReview() {

		Utility.sendKeysAction(driver, WriteAReviewLink,
				"WalletHub is the best destination for free credit scores & reports updated daily.  We also offer all the tools & insights needed..");
	}

	public void clickOnPolicyDropDown() {

		Utility.moveToElementAndClickAction(driver, PolicyDropDown);

	}

	public void selectHealthInsurance() {

		Utility.moveToElementAndClickAction(driver, HealthInsurance);
	}

	public void clickOnSubmitButton() {

		Utility.moveToElementAndClickAction(driver, SubmitButton);

	}

	public void navigateToWalletHubProfile() {

		driver.get(DataProviderFactory.getConfigDataProvider().getValue("url4"));

	}

	public void validateYourReview() {

		Assert.assertTrue(ValidateReview.isDisplayed());

	}
}
