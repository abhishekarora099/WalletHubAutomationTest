package com.Wallethub.Assignments.automation.pages;

import java.util.Set;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.Wallethub.Assignments.automation.factory.DataProviderFactory;
import com.Wallethub.Assignments.automation.utils.Utility;
import com.aventstack.extentreports.ExtentTest;

public class FacebookLoginPage {

	public WebDriver driver;
	public ExtentTest logger;

	@FindBy(xpath = "//input[@name='email']")
	private WebElement Email;

	@FindBy(xpath = "//input[@id='pass']")
	private WebElement Password;

	@FindBy(xpath = "//button[@name='login']")
	private WebElement LoginButton;

	@FindBy(xpath = "//span[contains(text(),'on your mind')]")
	private WebElement PostStatusSection;

	@FindBy(xpath = "//div[@class='_1mf _1mj']")
	private WebElement PostStatusTextBox;

	@FindBy(xpath = "//div[@aria-label='Post']")
	private WebElement PostButton;

	public FacebookLoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void inputEmailAddress() {

		Utility.sendKeysAction(driver, Email, DataProviderFactory.getConfigDataProvider().getValue("email1"));

	}

	public void inputPassword() {
		Utility.sendKeysAction(driver, Password, DataProviderFactory.getConfigDataProvider().getValue("password1"));
	}

	public void clickOnLoginButton() {
		Utility.moveToElementAndClickAction(driver, LoginButton);
		Utility.sleep(5);

	}

	public void clickOnPostStatusSection() {
		Utility.moveToElementAndClickAction(driver, PostStatusSection);

	}

	public void postStatusMessage() {

		Utility.sendKeysAction(driver, PostStatusTextBox, "Hello World");

	}

	public void clickOnPostButton() {

		Utility.moveToElementAndClickAction(driver, PostButton);
		Utility.sleep(5);

	}

}
