package com.Wallethub.Assignments.automation.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.Wallethub.Assignments.automation.factory.TestInitilizer;
import com.Wallethub.Assignments.automation.pages.FacebookLoginPage;
import com.Wallethub.Assignments.automation.pages.WallethubPage;
import com.Wallethub.Assignments.automation.utils.Utility;
import com.aventstack.extentreports.Status;

@Listeners(com.Wallethub.Assignments.automation.factory.TestListeners.class)
public class AllTests extends TestInitilizer {

	@BeforeMethod
	public void extentLoggerInitializer(Method method) {
		TestInitilizer.extentTest = report.createTest(method.getName());
	}

	@Test(enabled = true, priority = 0)
	public void FacebookLoginAndPostStatus() throws IOException {
		FacebookLoginPage facebookLoginPage = new FacebookLoginPage(driver);
		facebookLoginPage.inputEmailAddress();
		facebookLoginPage.inputPassword();
		facebookLoginPage.clickOnLoginButton();
		facebookLoginPage.clickOnPostStatusSection();
		facebookLoginPage.postStatusMessage();
		facebookLoginPage.clickOnPostButton();

	}

	@Test(enabled = true, priority = 1)
	public void Wallethub() throws AWTException {
		WallethubPage wallethubPage = new WallethubPage(driver);
		wallethubPage.navigateToWallethubRegistrationPage();
		wallethubPage.enterEmailAddress();
		wallethubPage.enterPassword();
		wallethubPage.enterConfirmPassword();
		wallethubPage.navigateToTestInsuranceCompanyUrl();
		wallethubPage.clickOnReviewsSection();
		wallethubPage.hoverOnRatingStars();
		wallethubPage.clickOnWriteAReviewLink();
		wallethubPage.enterReview();
		wallethubPage.clickOnPolicyDropDown();
		wallethubPage.selectHealthInsurance();
		wallethubPage.clickOnSubmitButton();
		wallethubPage.navigateToWalletHubProfile();
		wallethubPage.validateYourReview();

	}

	@AfterMethod
	public void tearDown(ITestResult result) throws IOException {
		if (ITestResult.FAILURE == result.getStatus()) {
			TestInitilizer.extentTest.log(Status.FAIL, "Test " + result.getName() + " has been failed");
			TestInitilizer.extentTest.log(Status.DEBUG, result.getThrowable());
			TestInitilizer.extentTest.addScreenCaptureFromPath(Utility.takeScreenshot(driver));

		}

	}

	@AfterClass
	public void closeBrowser() {
		driver.quit();
	}

}
