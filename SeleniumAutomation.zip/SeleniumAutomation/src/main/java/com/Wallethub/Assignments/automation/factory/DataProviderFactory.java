package com.Wallethub.Assignments.automation.factory;

import com.Wallethub.Assignments.automation.dataprovider.ConfigDataProvider;

public class DataProviderFactory {

	public static ConfigDataProvider getConfigDataProvider() {
		return new ConfigDataProvider();
	}
}
